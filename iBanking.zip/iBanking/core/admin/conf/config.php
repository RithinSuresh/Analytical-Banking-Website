<?php
    $dbuser="root";
    $dbpass="";
    $host="localhost";
    $db="martdevelopers_iBanking";
    $mysqli=new mysqli($host,$dbuser, $dbpass, $db);
